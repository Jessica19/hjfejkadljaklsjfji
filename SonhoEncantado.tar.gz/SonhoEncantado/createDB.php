<?php

	$con = mysqli_connect("localhost", "root", "password", "SonhoEncantado")or die ('N&acute;o foi poss&itilde;vel conectar: '.mysqli_connect_errno());

	$db = mysqli_select_db($con, "SonhoEncantado");

		/*query = "INSERT INTO `{$this->table}` (`name`, `email`, `salt`,`ePassword`, `address`, `meetStore`)*/

	$query = "CREATE TABLE `Admin` (

  `idAdmin` mediumint(8) unsigned NOT NULL auto_increment,

  `name` varchar(255),

  `email` varchar(255) default NULL,

  `salt` varchar(255) default NULL,

  `ePassword` varchar(511) default NULL,

  `position` varchar(511) default NULL,

  `daylySalt` varchar(255) default NULL,

  PRIMARY KEY (`idCliente`)

) AUTO_INCREMENT=1;
";
		
	$sql = mysqli_query($con, $query);
?>