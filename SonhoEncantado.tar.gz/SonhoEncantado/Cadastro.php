<Doctype html>
<html>
	<body>
		<form action="CriarConta.php" method="GET" >
			<div>
				<label for="name"> Nome: </label>
				<input type="text" name="name"> </input>				
			</div>
			<div>
				<label for="email"> Email: </label>
				<input type="text" name="e[mail"> </input>				
			</div>
			<div>
				<label for="userPass"> Senha: </label>
				<input type="password" name="userPass"> </input>				
			</div>
			<div>
				<label for="userPassConfirmation"> Confirma&ccedil;&atilde;o de Senha: </label>
				<input type="password" name="userPassConfirmation"> </input>
			</div>
			<div>
				<label for="address"> Endere&ccedil;o: </label>
				<input type="text" name="address"> </input>				
			</div>
			<div>
				<label for="meetStore"> Como conheceu nossa loja?</label>
				<input type="text" name="meetStore"> </input>				
			</div>
			<button type="submit" value="Submit">Enviar</button>
		</form>
	</body>
</html>