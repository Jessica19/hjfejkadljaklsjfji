<?php
    /*Inclue o menu principal*/
    include("menu.html");
    $con = mysqli_connect('localhost', 'root', 'newpass') or die('Error querying database');
    $db = mysqli_select_db($con, 'imagesMainPage') or die("Error conecting database ". mysql_errno());
    $query = mysqli_query($con, "SELECT * FROM slideShow") or die("Error last element not found");
    $information = mysqli_fetch_row($query);
    echo "<img class='' src=".$information[2].">";
    $information = mysqli_fetch_row($query);
    echo $information[2];
    echo "<img class='' src=".$information[2].">";

 ?>
    </body>
</html>