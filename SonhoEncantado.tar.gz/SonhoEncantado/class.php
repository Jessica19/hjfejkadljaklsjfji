<?php
    class MyClass
    {
        // As propriedades e metodos de classes vem aqui
    }

    $obj = new MyClass;

    var_dump($obj);
?>