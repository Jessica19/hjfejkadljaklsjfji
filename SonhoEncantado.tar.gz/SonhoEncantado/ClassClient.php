<?php
	class client{
		var $email;
		var $pass;
		var $confirPass;
		var $name;
		var $adress;

		function _construct
	}
?>