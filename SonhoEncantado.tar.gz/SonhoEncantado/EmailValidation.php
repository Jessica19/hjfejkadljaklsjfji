<?php
	function emailValidation($email){
		//validate the word before @
		$count = "^[a-zA-Z0-9\._-]+@";
		//validate domain of email 
		$domain = "[a-zA-Z0-9\._-]+.";
		//validare domain extension (tld)
		$domainExtension = "([a-zA-Z]{2,4})$";

		$pattern = $count.$domain.$domainExtension;

		if (ereg($pattern, $email))
			return true;
		else 
			return false;
	}

	$input = "margnasc@yahoo.com.br";

	if (emailValidation($input))
		echo "email is valid";
	else
		echo "this email is invalid";
?>