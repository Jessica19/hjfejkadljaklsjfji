<?php
	class Admin{
		
	}
?>