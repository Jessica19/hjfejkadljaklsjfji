<?php
	require_once 'user.class.php';
	$user = new User;
	$user->token = $_GET['save'];
	$user->Activate();
	echo "Dados salvos com sucesso\n.";
?>