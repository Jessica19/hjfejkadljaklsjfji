<?php
	class User{

		/**
		  * Name od database where table user is set
		  * @var string
		  */
		
		// var $dbName = "SonhoEncantado";	
		var $dbName = "u401548396_loja";
		/**
		  * Password to connect to database
		  * @var string
		  */

		var $dbPassword = "password"; 

		/**
		  * database user
		  * @var string
		  */

		// var $root = "root"; 
		var $root = "u401548396_root";
		/**
		  * where the database is set
		  * @var string
		  */

		var $host = "localhost"; 

		/**
		  * name of user table
		  * @var string
		  */

		var $table = "Client";

		/**
		  * Save user's email
		  * @var string
		  */

		var $email; 

		/**
		  * Save user's password
		  * @var string
		  */

		var $userPass;

		/**
		  * Save user's password confirmation
		  * @var string
		  */
		
		var $userPassConfirmation;
		
		/**
		  * Save encrypted password
		  * @var string
		  */

		var $ePassword;
		/**
		  * Save the error type
		  * @var number
		  */
		
		var $error;


		var $address = NULL; //usersAdress
		var $name = NULL; //user name
		var $meetStore = NULL; // how user know store
		var $salt;//md5 salt
		
		/**
		  * Fild name caugth in user table and saved in the session
		  * if false no data is consulted
		  * @var mixed
		  */
		var $data = array('idClient', 'name');
		
		/**
		  * initiate session if necessary
		  * @var boolean
		  */
		var $startSession = true;
		
		/**
		  * key session prefix
		  * @var string
		  */
		var $keyPrefix = 'user_';
		
		/**
		  * Use a cookie to improve safety?
		  * @var string
		  */
		var $cookie = true;

		/*
		  * name of fields where user name and user password are set
		  */

		var $fields = array(
			'name' => 'name',
			'email' => 'email',
			'salt' => 'salt',
			'ePassword' => 'ePassword'
			 );

		/**
		  * Saves the token 
		  * @var string
		  */

		 var $token;

		/**
		  * Instantiate user data
		  * 
		  * @param string $email - User email
		  * @param string $userPass - User password
		  */

		function _construct($email, $userPass, $userPassConfirmation, $name, $address, $meetStore){
			$this->email = $email;
			$this->userPass = $userPass;
			$this->error = NULL;
			$this->userPassConfirmation = $userPassConfirmation; 
			$this->name = $name;
			$this->address = $address;
			$this->meetStore = $meetStore;
		}

		/**
		  * Validate the form of email (10)
		  *
		  * @param array $count- validate the word before @
		  * @param array $domain - validate domain of email 
		  * @param array $domainExtension - validate domain extension (tld) 
		  * @param array $pattern - concatenation of $domain/$count/$domainExtension
		  * @return bollean - Valid email or not
		  */

		function ValidateEmail(){

			$count = "^[a-zA-Z0-9\._-]+@";
			$domain = "[a-zA-Z0-9\._-]+.";
			$domainExtension = "([a-zA-Z]{2,4})$";

			$pattern = "/".$count.$domain.$domainExtension."/";
			$pattern2 = "/".$count.$domain.$domainExtension.$domainExtension."/";
			echo $pattern;
			if ((preg_match($pattern, $this->email)) or (preg_match($pattern2, $this->email)))
				return true;
			else {
				$this->error = 101;
		 		return false;
			}
		}
		
		/**
		  * Validate user password (20)
		  * 
		  * @return boolean - password is equal or equal to email
		  */

		function ValidatePassword(){
		
			if ( strcmp($this->userPassConfirmation, $this->userPass)!= 0){
				$this->error = 201;
				return false;
			}
			return true;
		}

		/**
		  * Verifies password strength (30)
		  *
		  * @param array $lowerLetter - lower letters of alphabet
		  * @param array $upperLetter - upperLetters of alphabet
		  * @param array $digit - numeric digits
		  * @param 
		  */

		function PasswordStrength(){
			$this->userPass;
			$lowerLetter = "[a-z]";
			$upperLetter = "[A-Z]";
			$digits = "[0-9]";
			$caracter = "[]";
			
			if (!preg_match($lowerLetter, $this->userPass)){
				$this->error = 301;
				return false;
			}
			if (!preg_match($upperLetter, $this->userPass)){
				$this->error = 302;
				return false;
			}
			if (!(preg_match($digits, $this->userPass))){
				$this->error = 303;
				return false;
			}
			return true;
		}

		/** 
		  * Get Information from database (40)
		  * 
		  * @param string $query - recieves instruction for db
		  * @param number $function - discover with function we are dealinh (SELECT, INSERT, RENAME)
		  * $function = 1 - SEEK USER
		  * $function = 2 - ADD USER
		  * @param array $row - data information about existing user
		  * @param string $email - Email validation
		  * @param strig $userPass - User Password validation
		  * @return boolean - Existing user or not
		  */
		
		function ConnectDatabase($query, $function){	

			$con = mysqli_connect($this->host, $this->root, $this->dbPassword, $this->dbName)or die ('N&acute;o foi poss&itilde;vel conectar: '.mysqli_connect_errno());

			$db = mysqli_select_db($con, $this->dbName);
			
			$sql = mysqli_query($con, $query);

			$row = mysqli_fetch_array($sql);

			switch ($function) {

				case 1:
					# SEEK USER/
					if(is_null($row[0])){
						mysqli_close($con);
						return false;
					}
					else{
						$this->salt = $row[3];
						$this->ePassword = $row[4];
						mysqli_close($con);
						return true;
					}
					break;

				case 2:
					# ADD NEW USER
					if(!$sql){
						die('Could not enter data: ' . mysqli_error($con));
						$this->error = 402;
						return false;
					}
					else
						return true;

				default:
					# code...
					return NULL;
					break;
			}
		}

		/**
		  * This function verifies if name has space
		  * we admit that most names simple and we have at 
		  * least one last name (60)
		  * 
		  * @param array $space - this array contains one space
		  * @return bool - true for sucess false for error
		  */

		function ValidateName(){
			$space = "[ ]";
			if (!preg_match($space, $this->name)){
				$this->error = 601;
				return false;
			}
			return true;
		}

		/**
		  * This function sends an email to verify if it is a valid email
		  *
		  * @param string 
		  * @return bool - true for email sent false for error
		  */

		function SendEmail(){
			

			$msg = "Agradecemos pelo seu cadastro.\n Clique no link para efetuarmos o cadastro 
			http://sonhoencantado.esy.es/SonhoEncantado/saveData.php?save=".$this->token;

			// use wordwrap() if lines are longer than 70 characters
			$msg = wordwrap($msg,70);

			// send email
			mail($this->email,"My subject",$msg);
		}
		/**
		  * Add a new client in the database (50)
		  *
		  * @param bool $existUser - see if the email already exists
		  * @param bool $validadeEmail - true if is email valid or false if it's not
		  * @param string $query - mysql query database
		  * @param string $ePassword - md5 encrypted user password  
		  * @param string $size - size of salt
		  * @return bool - true added successfully false there is an error
		  */

		function AddUser(){

			if (is_null($this->name)){
				$this->error = 501;
				return false;
			}

			if (is_null($this->meetStore)){
				$this->error = 502;
				return false;
			}

			if (!$this->ValidatePassword())
				return false;
			
			if (!$this->ValidateName())
				return false;
		
			$query = "SELECT * FROM `{$this->table}`
			WHERE `{$this->fields['email']}` = '{$this->email}'";
			$existUser = $this->ConnectDatabase($query, 1);
			
			if ($existUser){
				$this->error = 503;
				return false;
			}
		
			if (!$this->ValidateEmail()){
				echo "oi\n";
				return false;
			}

			$token_size = 30;
			$this->token = substr(sha1(mt_rand()), 0, $token_size);
			
			echo $this->token;
			$size = 22;
			$this->salt = substr(sha1(mt_rand()), 0, $size);
			$ePassword = md5($this->userPass.$this->salt);
	
			$query = "INSERT INTO `{$this->table}` (`name`, `email`, `salt`,`ePassword`, `address`, `meetStore`,`active`,`reset_password`)
			 VALUES ('{$this->name}', '{$this->email}', '{$this->salt}','{$ePassword}', '{$this->address}', '{$this->meetStore}',
			 	'{$this->token}','0');";

			$existUser = $this->ConnectDatabase($query, 2);

			return true;			
		}

		/**
		  * This function activate users acount
		  *
		  */

		function Activate(){	

			$query = "UPDATE `{$this->table}` SET `active`='1' WHERE `active` = '{$this->token}'";

			$con = mysqli_connect($this->host, $this->root, $this->dbPassword, $this->dbName)or die ('N&acute;o foi poss&itilde;vel conectar: '.mysqli_connect_errno());

			$db = mysqli_select_db($con, $this->dbName);
			
			$sql = mysqli_query($con, $query);

		}

		/**
		  * this function add a new adress or change the existig address (70)
		  * 
		  * @param string $query - mysql query database
		  * @return bool - true for success false for fail
		  */

		function NewAddress(){

			$query = "UPDATE $this->table SET address='$this->address' WHERE email='$this->email'";

			if (!$this->ConnectDatabase($query, 2)){
				$this->error = 701;
				return false;
			}
			return true;
		}
 
		/**
		  * This method validate users login
		  * @param $query string - myslq query for email
		  * @param $existUser boolean - true if exist 
		  * @param $password string - encrypted password with the same salt of database
		  * @return boolean - true if its ok
		  */

		function UserLogin(){
			
			if (is_null($this->email)){
				$this->error = 801;
				return false;
			}

			if (is_null($this->userPass)){
				$this->error = 802;
				return false;
			}

			$query = "SELECT * FROM `{$this->table}`
			WHERE `{$this->fields['email']}` = '{$this->email}'";
			$existUser = $this->ConnectDatabase($query, 1);
			
			if (!$existUser){
				$this->error = 803;
				return false;
			}

			$password = md5($this->userPass . $this->salt);

			if(strcmp($password, $this->ePassword)==0){
				$this->error = 804;
				return false;
			}

			return true; 
					
		}

		/**
		  * This method save an user in the system saving your data in session
		  *
		  * @param string $user - Loged user
		  * @param string $password - userPassword
		  * @return boolean - if user was loged or not
		  */

		function UserStay(){

			if(!$this->UserLogin()){
				return false;
			}

			if ($this->startSession and !isset($_SESSION)){
				session_start();
			}
			
			// Bring data from table 

			if($this->data != false){
				// add user field in data list
				if (!in_array($this->fields['name'], $this->data)){
					$this->data = 'user';
				}

				// set up in SQL form of field list
				$data = '`'.join('`, `', array_unique($this->data)).'`';
			}

			// confer data
			
			$sql = "SELECT {$data}
				FROM `{$this->table}`
				WHERE `{$this->fields['email']}` = '{$this->email}'";
			
			$con = mysqli_connect($this->host, $this->root, $this->dbPassword)or die ('N&acute;o foi poss&itilde;vel conectar: '.mysqli_connect_errno());

			$db = mysqli_select_db($con, $this->dbName);
						
			$query = mysqli_query($con, $sql) or die ("deu ruim\n");

			//bring data found to an array
			$data = mysqli_fetch_array($query);

			//if confer fails
			if(is_null($data[0])){
				// confer wasn't successeful, return false
				$this->error = 901;
				mysqli_close($con);
				return false;
			}else{
				
				//clean memory confer
				mysqli_free_result($query);

				//pass data to the session
				foreach ($data as $key => $value) {
					
					$_SESSION[$this->keyPrefix . $key] = $value;
				}
			}

			//User logged successfuly
			$_SESSION[$this->keyPrefix . 'logged'] = true;

			//Define a cookie for most safety 
			if($this->cookie){
				//set up a cookie with general information about user
				$value = join('#', array($this->name, $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']));

				//encrypt cookie value
				$value = sha1($value);

				setcookie($this->keyPrefix . 'token', $value, 0, '/');
			}

			// end of inspection, returns true 
			return true;
		}

		/**
		  * Verifies if it is an user logged int the sistem
		  *
		  * @return boolean - if it is an user logged or not 
		  */

		function UserLogged(){

			// start session ?
			if ($this->startSession AND !isset($_SESSION)){
				session_start();
			}
			
			//verifies if there isn't any value in the session
			if (!isset($_SESSION[$this->keyPrefix . 'logged']) OR 
				!$_SESSION[$this->keyPrefix . 'logged']){
				echo $_SESSION[$this->keyPrefix . 'logged'];
				$this->error = 1001;
				return false;
			}

			// make cookie verification 
			if ($this->cookie){
				// see if the cookie does not exists
				if (!isset($_COOKIE[$this->keyPrefix.'token'])){
					$this->error = 1002;
					return false;
				} else{
					// arranges cookie's value
					$value = join('#',array($_SESSION[$this->keyPrefix . 'name'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']));
					//encrypt cookies values
					$value  = sha1($value);

					//verifies cookie value
					if (strcmp($_COOKIE[$this->keyPrefix . 'token'],$value)!=0){
						$this->error = 1003;
						return false;
					}

				}
			}
			//  session and cookie were verified, there is an user logged
			return true;
		}

		/**
		  * do user logout
		  *
		  * @return boolean
		  */

		function logout(){

			// start session 
			if ($this->startSession AND !isset($_SESSION)){
				session_start();
			}

			//prefix size
			$size = strlen($this->keyPrefix);

			//destory every values of session relative to sistem login
			foreach ($_SESSION as $key => $value) {
				//Removes only values with keys start as your correct prefix
				if (substr($key, 0, $size) == $this->keyPrefix){
					unset($_SESSION[$key]);
				}
			}

			//Destroy the session if it's empty
			if (count($_SESSION) == 0){
				session_destroy();

				//Remove session's cookie if it exists
				if (isset($_COOKIE['PHPSESSID'])){
					setcookie('PHPSESSID', false, (time() - 3600));
					unset($_COOKIE['PHPSESSID']);
				}
			}

			//Remove cookie with user information
			if ($this->cookie AND isset($_COOKIE[$this->keyPrefix . 'token'])){
				setcookie($this->keyPrefix . 'token' , false , (time() - 3600), '/' );
				unset($_COOKIE[$this->keyPrefix . 'token']);
			}
			
			//Return IF there isn't any user logged
			if ($this->UserLogged()){
				return false;
			} 
			
			$this->error = null;
			return true;
		}
		/**
		  * Print error number
		  */

		function Error(){
			echo $this->error;
		}

		/**
		  * Print error type
		  */

		function Errno(){
			switch ($this->error) {

				case 101:
					echo "Email do not exist\n";
					break;

				case 201:
					echo "Password and Confirm Password do not match\n";
					break;

				case 301:
					echo "Password must contain lower letters\n";
					break;

				case 302:
					echo "Password must contain upper letters\n";
					break; 

				case 303:
					echo "Password must contain digits\n";
					break;

				case 402:
					echo "Error adding new user\n";
					break;

				case 501:
					echo "Name not introduced\n";
					break;

				case 502:
					echo "Please write or select how you know our store\n";
					break;

				case 503:
					echo "This email already exists\n";
					break;

				case 601:
					echo "You forgot your last name\n";
					break;

				case 701:
					echo "Trouble saving new data\n";
					break;

				case 801:
					echo "Enter an email\n";
					break;

				case 802:
					echo "Enter a password\n";
					break;

				case 803:
					echo "Invalid email\n";
					break;

				case 804:
					echo "Invalid password\n";
					break;

				case 901:
					echo "Data confer is invalid\n";
					break;

				case 1001:
					echo "_SESSION is empty\n";
					break;

				case 1002:
					echo "Cookie does not exist\n";
					break;

				case 1003:
					echo "Cookie value does not match\n";
					break;

				default:
					echo "no trouble\n";
					break;
			}
		}
	}
?>
