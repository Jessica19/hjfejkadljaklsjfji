<?php
	// require "/var/www/html/Hackathon/ProcurarBancoDados.php";

	// $centro = $_GET['centro'];
	
	require "/home/u569143437/public_html/Hackathon/ProcurarBancoDados.php";

	$centro = $_POST['centro'];
	/*confere se o centro existe*/
	$selecionado = 'Id_Centro';
	$seletor = 'Nome_Centro';
	$existeCentro = ExisteUsuario('Centro', $selecionado,$seletor,$centro);
	/*Nao existe*/
	if ($existeCentro > 0)
		echo "-1";
	else{
		/*Existe o centro*/
		$Id_Centro = ProcurarDados('Centro', $selecionado, $seletor, $centro)[0];
		$secretariaArray = ProcurarDados('Secretarias', 'Nome_Secretaria', 'Id_Centro', $Id_Centro);
		while (!$secretariaArray[i])
		{
			$i = $i + 1;
		}
		echo $i;
		for ($j =0 ; $j < $i ;$j++ )
			echo $secretariaArray[$j];

	}	
?>