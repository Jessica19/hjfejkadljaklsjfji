<?php
	require_once 'user.class.php';
	$user = new User;
	$user->email = "abcd@yahoo.com.br";
	$user->userPass = "12345aA";
	$user->userPassConfirmation = "12345aA";
	$user->name = 'Davi Nascimento';
	$user->address = "Rua Simon Bolivar";
	$user->meetStore = "facebook";
	ini_set('display_errors', 'On');
	error_reporting(E_ALL | E_STRICT);

// $envio = mail ("jessy_n.r@windowslive.com", "Assunto da Mensagem", "Conteúdo do
// e-mail", "jessy_n.r@windowslive.com");
// if($envio)
 // echo "Mensagem enviada com sucesso";
// else
 // echo "A mensagem não pode ser enviada";
// 	// $a = $user->UserLogin();
// 	// if($a == TRUE)
// 	// 	echo "sucesso\n";
// 	// else
// 	// 	echo "fracasso\n";
// 	// //$user->UserStay();
	
$user->AddUser();
$user->Errno();

	// if($user->seekUser())
	// 	echo "ok";
	// else
	// 	echo "esperado";

?>