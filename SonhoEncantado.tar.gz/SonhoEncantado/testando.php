<?php
	
	require "/var/www/html/Hackathon/ProcurarBancoDados.php";
	
	$enderecoEmail = $_POST['enderecoEmail'];
	$senha = $_POST['senha'];

	$existe = ExisteUsuario('Usuario', 'salt', 'enderecoEmail', $enderecoEmail);	

	 if ($existe < 0){
	 	echo "1";
	 }
	 else{
	 	$salt = ProcurarDados('Usuario', 'salt','enderecoEmail', $enderecoEmail);
		$confereSenha = ProcurarDados('Usuario', 'senha','enderecoEmail', $enderecoEmail);
		$senha = EncriptarSenha($senha, $salt);
		if ($confereSenha == $senha)
			echo "1";
	}


?>
