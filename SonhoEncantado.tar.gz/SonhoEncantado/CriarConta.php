<?php
	require_once 'user.class.php';
	$user = new User;
	$user->email = $_GET['email'];
	$user->userPass = $_GET['userPass'];
	$user->error = NULL;
	$user->userPassConfirmation = $_GET['userPassConfirmation'];
	$user->name = $_GET['name'];
	$user->address = $_GET['address'];
	$user->meetStore = $_GET['meetStore'];
	ini_set('display_errors', 'On');
	error_reporting(E_ALL | E_STRICT);
	
	$user->Error();	
	$user->AddUser();
	if (strcmp($user->Errno(), "no trouble")){
		echo "Nos enviaremos um email de confirmacao apos isso sua conta estara liberada para uso";
	}
	$user->SendEmail();
?>
